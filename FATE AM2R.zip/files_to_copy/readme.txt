This mod was made by Sabor Zero. A machine translated version of the Readme can be found further down.

Fate AM2R
creator: Sabor Zero
https://www.youtube.com/channel/UCNCoXc6aopYgEZPXqtCJdsw

------------------------------------------------------------
同梱のセーブファイル（sav3）は、Hyper, Dark Suit, Infinity Dash を最初から装備した状態でスタートするもの。
難易度はノーマル。

　セーブファイルを置く場所
　　　C:\Users\[ユーザー名]\AppData\Local\AM2R

------------------------------------------------------------

v1.1の改造版。変更内容は以下。

・装備入れ替え：Plasma→Hyper、Gravity Suit→Dark Suit、Speed Booster／Infinity Dash
　　　Infinity DashはDARK SUIT装備時に使用可能。Speed BoosterがInfinity Dashに自動的に切り替わる。
　　　Infinity Dashはその場でいきなりシャインスパークが使える装備。AIM ROCK ボタンで発動。
　　　Hyperはメトロイド系にもダメージが行く。スーパーミサイルに近い威力。ガンマが2～3発で落とせるほど。
　　　　クイーンで試した感じでは、スーパーミサイルの70％程度？の威力になっている。
　　　なおHyperのみ、アイテムアイコンや取得時の名前は元のままである。Dark Suitは反映されていた。

・タイトル画面変更。

・BGMも変更。エリアBGM以外の大半は差し替えられた。脱出の曲だけスーパーメトロイド。ほかはいずれもFate関連の曲？
　　　　musAncientGuardian.ogg、musArachnus.ogg、musArea7A.ogg、musArea7C.ogg、musCredits.ogg、
　　　　musEris.ogg、musHatchling.ogg、musIntroSeq.ogg、musItemAmb.ogg、musMonsterAppear.ogg、musOmegaFight.ogg、musQueen.ogg、musQueenIntro.ogg
　　　　musReactor.ogg、musTitle.ogg、musTorizoA.ogg、musTorizoB.ogg、musZetaFight.ogg

・効果音追加？sndTorizoWingsDeploy.ogg

・難易度の名前や装備の効果の説明文、オープニングメッセージを Fate/stay night 風に変更。
　　（EASY→SERVANT、NORMAL→MASTER、HARD→HERO）

・敵の攻撃力は2倍になっている。Easy,Normal（※Master）でザコ、アルファメトロイドからのダメージが倍になっていた。

・Easy、Normalで雑魚の耐久力倍増。ユンボ耐久力2、ユーミーの耐久力2、ピンサーの耐久力も5、ツムリが4。
　　ただしクイーンメトロイドは従来位通りだった。最初のアルファメトロイドも耐久力同じ。


・Galleryは選択できない。クリアし直しても選べない。
・Mission Log の目次に Speed Booster or Infinity Dash の文字が大量に表示されるバグ。
・スクリューアタックが光らない。電気を帯びない。
・幼生メトロイド登場エリアの右向きのドアにゴミのようなグラフィック化け表示。

------------------------------------------------------------
The included save file (sav3) will start you off with Hyper, Dark Suit, and Infinity Dash.
Difficulty level is Normal.

 Where to put the save file
   C:\Users\[username]\AppData\Local\AM2R

------------------------------------------------------------

This is a modified version of v1.1. The changes are as follows.

Equipment swapping: Plasma to Hyper, Gravity Suit to Dark Suit, Speed Booster/Infinity Dash.
   Infinity Dash can be used when Dark Suit is equipped, and Speed Booster will automatically switch to Infinity Dash.
   Infinity Dash allows you to use Shine Spark on the spot, and can be activated by pressing AIM ROCK.
   Hyper also damages Metroid types. It's almost as powerful as the Super Missile. It's so powerful that it can take out a Gamma in two or three shots.
    It's almost as powerful as a Super Missile. It's about 70% as powerful as a Super Missile.
   For Hyper, the item icons and names are the same as before, but for Dark Suit, the changes are reflected.

Title screen changed.

BGM also changed. The title screen was changed, and most of the BGM was replaced except for the area BGM. Only the escape music is Super Metroid. The other songs are all Fate related?
    musAncientGuardian.ogg, musArachnus.ogg, musArea7A.ogg, musArea7C.ogg, musCredits.ogg
    musEris.ogg, musHatchling.ogg, musIntroSeq.ogg, musItemAmb.ogg, musMonsterAppear.ogg, musOmegaFight.ogg, musQueen.ogg, musQueenIntro.ogg
    musReactor.ogg, musTitle.ogg, musTorizoA.ogg, musTorizoB.ogg, musZetaFight.ogg

Add sound effects? sndTorizoWingsDeploy.ogg

Changed difficulty names, equipment effect descriptions, and opening message to look like Fate/stay night.
  (EASY?SERVANT, NORMAL?MASTER, HARD?HERO)

Enemies' attack power has been doubled, and damage from Zakos and Alpha Metroid has been doubled in Easy and Normal (*Master).

Doubled durability of small fish in Easy and Normal. In Easy and Normal, the durability of mooks is doubled: 2 for Yumbo, 2 for Yumi, 5 for Pincer, and 4 for Tsumuri.
  The Queen Metroid, however, was the same as before. The first Alpha Metroid has the same durability.


You can't select Gallery. The first Alpha Metroid had the same durability.
There is a bug that the table of contents in the Mission Log displays a lot of Speed Booster or Infinity Dash text.
The screw attack doesn't light up. Screw attack doesn't glow and doesn't take on electricity.
The door facing right in the area where the infant Metroid appears has a garbage graphic.

---------------------

Olivier オリヴィエ <gamo0805@live.ca


bit.ly/AM2Rblog
-----------------------------------------------------------

SYSTEM REQUIREMENTS
- DirectX9.0 or newer installed.


INSTALLATION
Unzip the contents of the archive in a folder and run the exe.


KEYS
To configure the game keys and joypad buttons, go to the options screen. 
You can change any game options, including the controls, during gameplay.
XBox 360 Gamepads are detected automatically.

F11 - Show FPS
F12 - Capture Screenshot
ESC - Options Menu
Alt+Enter - Toggle Fullscreen
Alt+F4 - Exit Game

FAQ
- Where are my screenshots? I can't find them anymore!
Look in your AppData/Local folder, it's usually in this location:
C:\Users\[Your User Name]\AppData\Local\AM2R

- Why are my screenshots so big?
The screenshots are now taken with the size of the displayed window.
If you want the classic 320x240 screenshots, set the display to Windowed 1x
before pressing F12.

- Can I use my old saves?
No. The game changed a lot since the demo, along with the save format.

- I have an Arcade cabinet, can I exit AM2R with just 1 key?
Sure! After running the game once, go to this folder:
C:\Users\[Your User Name]\AppData\Local\AM2R
And edit config.ini, setting the following values:
EnableExitButton=1 (should be 0 by default)
KeyboardButtonExit, JoystickButtonExit and XBJoypadButtonExit can be used to
customize which button / key is used to exit. Default is ESC for keyboard,
Back for XInput, and button 10 for DirectInput.



CHANGELOG

1.1
- Fixed gravity suit not being rendered in certain systems
- Fixed room transition in area 3 entrance
- Fixed language file detection, the game can be fully translated now
- Added transport pipe to final area
- Other minor fixes



CREDITS

Producer
Milton 'DoctorM64' Guasti

Graphic Design
Ramiro Negri
Steve 'Sabre230' Rothlisberger
Jack Witty
Kirill '1Eni1' Fevralev
Jasper
MichaelGabrielR

Promo Art
Azima 'Zim' Khan

Writing Assistant
James 'Ridley' Hobbs
Paulo 'Latinlingo' Villalobos

Platform Engine Code
Martin Piecyk

Music Composition
Milton 'DoctorM64' Guasti
Darren Kerwin
Torbjørn 'Falcool' Brandrud

Debug
Hemse
Dragondarch
Esteban 'DruidVorse' Criado
Verneri 'Naatiska' Viljanen

Playtest
Jennifer Potter
Mario Crestanello
Live4Truths
Torbjørn 'Falcool' Brandrud
Lise Trehjørningen
Nommiin
Gabriel Kaplan
Nicolas 'Skol' Del Negro
Darren Kerwin
Robert Sephazon

Community Management
Dragonheart91
Ammypendent
Karrde

Special Thanks
Nommiin
Nathan 'wickedclown' Hess
Tyler Rogers
Kousoru
Infinity's End
CapCom
Isabelle Amponin
The game' community

-----------------------------------------------------------
For updates on the project, visit:
bit.ly/AM2Rblog
